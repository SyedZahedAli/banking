package AccountStratergy;

import java.util.Scanner;

import model.Account;

public class PersonalAccount extends AccountProcessor {

    // private final Scanner in = new Scanner(System.in);

    private Account account;

    public PersonalAccount(Account account) {
        this.account =account;
	}

	@Override
    public void builDeshBoard() {
        System.out.println("Account Type : Personal");
        System.out.println("Enter 4 digit pin to login :");
        String pin = in.next();
        if(pin == null || pin.length() != 4 || !pin.equals(account.getPin())){
            in.close();
            throw new RuntimeException("User Entered Invalid Pin.");
        }
        commonProcess(account.getAccountNumber());
        in.close();
    }

    
    
}