package AccountBuilder;

import AccountStratergy.AccountStratergy;
import AccountStratergy.BusinessAccount;
import AccountStratergy.PersonalAccount;
import constants.AccountType;
import dao.AccountDao;
import model.Account;

public class AccountBuilder {
    
    private int accountNumber;

    public AccountBuilder( int accountNumber){
        this.accountNumber =accountNumber;
    }

    public AccountStratergy getAccount(){
        AccountDao accountDao = new AccountDao(accountNumber);
        String[] accountDetail = accountDao.getAccountDeatils();
        if(accountDetail == null){
            throw new RuntimeException("Enable to fetch account Details");
        }
        AccountType accountType=  getAccountTypeInfo(accountDetail[1]);
        // System.out.println("Account Type:" + accountType.getValue());
        Account account = new Account();
        account.setAccountNumber(accountNumber);
        account.setAccountType(accountType);
        if(accountType == AccountType.PERSONAL){
            account.setPin(accountDetail[2]);
            return new PersonalAccount(account);

        }else{
            account.setCode(accountDetail[3]);
            account.setEmpId(accountDetail[4]);
            return new BusinessAccount(account);
        }
    }

    public AccountType getAccountTypeInfo(String accountType){
        if(accountType.equals(AccountType.PERSONAL.getValue())){
            return AccountType.PERSONAL;
        }
        return AccountType.BUSINESS;
    }
}