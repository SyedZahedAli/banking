import java.util.Scanner;

import AccountBuilder.AccountBuilder;
import AccountStratergy.AccountStratergy;

public class run {

    public static void main(String[] args) {
        System.out.println("Welcome to William Jessup Bank");
        System.out.println("Please enter your account number and press enter:");
        Scanner in = new Scanner(System.in);
        int accountNumber = in.nextInt();
        AccountStratergy account = new AccountBuilder(accountNumber).getAccount();
        account.builDeshBoard();
    }
    
}