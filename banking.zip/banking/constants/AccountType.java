package constants;

public enum AccountType {
    PERSONAL("PERSONAL"), BUSINESS("BUSINESS");

    private String accountType;

    AccountType(String accountType){
        this.accountType = accountType;
    }

    public String getValue(){
        return accountType;
    }
}