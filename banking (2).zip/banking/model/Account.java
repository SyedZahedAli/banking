package model;

import constants.AccountType;

public class Account {
 
    private int accountNumber;

    private String name;

    private AccountType accountType;

    private String pin;

    private String code;

    private String empId;

    public Account(){}

    public Account(int accountNumber, String name, AccountType accountType, String pin, String code, String empId) {
        this.accountNumber = accountNumber;
        this.name =name;
        this.accountType = accountType;
        this.pin = pin;
        this.code = code;
        this.empId = empId;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}