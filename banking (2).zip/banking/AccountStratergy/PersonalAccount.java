package AccountStratergy;

import model.Account;

public class PersonalAccount extends AccountProcessor {

    private Account account;

    public PersonalAccount(Account account) {
        this.account =account;
	}

	@Override
    public void builDeshBoard() {
        System.out.println("Enter 4 digit pin to login :");
        String pin = in.next();
        if(pin == null || pin.length() != 4 || !pin.equals(account.getPin())){
            in.close();
            throw new RuntimeException("User Entered Invalid Pin.");
        }
        System.out.println("Account Type : Personal, customer name :" +account.getName());
        commonProcess(account.getAccountNumber());
        in.close();
    }

}