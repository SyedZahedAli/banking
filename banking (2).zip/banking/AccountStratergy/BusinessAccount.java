package AccountStratergy;

import model.Account;

public class BusinessAccount extends AccountProcessor{
    
    private Account account;

    public BusinessAccount(Account account) {
        this.account =account;
    }

    @Override
    public void builDeshBoard() {
        System.out.println("Enter Company code:");
        String code = in.next();
        System.out.println("Enter employee Id :");
        String empID= in.next();
        if(code == null || empID == null || !code.equals(account.getCode()) || !empID.equals(account.getEmpId())){
            in.close();
            throw new RuntimeException("User Entered Invalid Company Code or Employee ID.");
        }
        System.out.println("Account Type : Business, customer name :" +account.getName());
        commonProcess(account.getAccountNumber());
        in.close();
    }

    
}