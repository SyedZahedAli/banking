package AccountStratergy;

import java.util.Scanner;

import dao.AccountDao;

public abstract class AccountProcessor implements AccountStratergy {

    protected final Scanner in = new Scanner(System.in);
    
    private final AccountDao accountDao = new AccountDao();

    public void printAvailableOptions(){
        System.out.println("Please select one of the following operations, by choosing [1-4]");
        System.out.println("1. Balance Enquiry");
        System.out.println("2. Deposit");
        System.out.println("3. Withdrawal");
        System.out.println("4. Quit");
    }

    public void commonProcess(int accountNumber){
        printAvailableOptions();
        int option = in.nextInt();
        performOperation(option, accountNumber);
    }

    public void performOperation(int Option, int accountNumber){
        if(Option == 1){
            int balance = accountDao.getCurrentBalance(accountNumber); 
            System.out.println("Current Balance : "+ balance);
            commonProcess(accountNumber);
        }else if(Option == 2){
            System.out.println("Enter amount for deposit:");
            int deposit = in.nextInt();
            accountDao.depositAmount(accountNumber, deposit);
            commonProcess(accountNumber);
        }else if(Option == 3){
            System.out.println("Enter amount for Withdrawal:");
            int withdrawal = in.nextInt();
            accountDao.withdrawalAmount(accountNumber, withdrawal);
            commonProcess(accountNumber);
        }else if(Option == 4){
            System.out.println("Thank you for using our service. Have a Great day ahead!");
        }else{
            throw new RuntimeException("Invalid Option Selected, Terminatin process ...");
        }
    }
}