package AccountStratergy;

public interface AccountStratergy {

    public void builDeshBoard();
    
}