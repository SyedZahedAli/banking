package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class AccountDao {

    private int accountNumber;

    private BufferedReader reader;

    // private BufferedWriter writer;

    public AccountDao() {
    }

    public AccountDao(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String[] getAccountDeatils() {

        try {
            reader = new BufferedReader(new FileReader("./db/accounts.txt"));
            String line = reader.readLine();
            while (line != null) {
                // System.out.println(line);
                String[] accountDetail = line.split(" ");
                if (Integer.valueOf(accountDetail[0]) == this.accountNumber) {
                    reader.close();
                    return accountDetail;
                }
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getCurrentBalance(int accountNumber) {
        try {
            reader = new BufferedReader(new FileReader("./db/account_credit.txt"));
            String line = reader.readLine();
            while (line != null) {
                // System.out.println(line);
                String[] accountDetail = line.split(" ");
                if (Integer.valueOf(accountDetail[0]) == accountNumber) {
                    reader.close();
                    return Integer.valueOf(accountDetail[1]);
                }
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void depositAmount(int accountNumber, int deposit) {
        int curBalance = getCurrentBalance(accountNumber);
        int balance = curBalance + deposit;
        writeOpDb("./db/account_credit.txt", accountNumber, balance);
    }

    public void withdrawalAmount(int accountNumber, int withdrawal) {
        int curBalance = getCurrentBalance(accountNumber);
        if (curBalance < withdrawal) {
            throw new RuntimeException("Sorry, Can not withdrawal requested amount. [Insufficient fund]");
        }
        int balance = curBalance - withdrawal;
        writeOpDb("./db/account_credit.txt", accountNumber, balance);
    }

    public void writeOpDb(String dbFile, int accountNumber, int balance) {
        try {
            Path path = Paths.get(dbFile);
            List<String> records;

            records = Files.readAllLines(path, StandardCharsets.UTF_8);

            int recordNumber = 0;
            while (true) {
                String[] record = records.get(recordNumber).split(" ");
                if (Integer.valueOf(record[0]) == accountNumber) {
                    break;
                }
                recordNumber++;
            }
            String recordData = String.valueOf(accountNumber) + " " + String.valueOf(balance);
            records.set(recordNumber, recordData);
            Files.write(path, records, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}